
d3.namespace("xmlns:cge","http://iec.ch/TC57/2005/SVG-schema#");

var lbss = [];
var svgSnap = d3.select("body").append("svg");
svgSnap.attr("width", 4000)
   .attr("height", 3000)
   .attr("xmlns", "http://www.w3.org/2000/svg")
   .attr("xmlns:xlink", "http://www.w3.org/1999/xlink")
   .attr("xmlns:cge", "http://iec.ch/TC57/2005/SVG-schema#");
var layerSnap = svgSnap.append("g").attr("id","Snap_Layer");

var grid = 64;
var currentSnapX = grid * 1;
var currentSnapY = grid * 1;

var startEl = 253;

var startNode = networkMap[startEl];

var handledNodes = {};
var ends = [];
function loopNode(nodes, nodeKey, nodeValue, prevNodeId) {
	var cids = [];
	$.each(nodeValue, function(key, value) {
		if (!prevNodeId || key != prevNodeId) {
			cids.push(key);
			loopNode(nodes, key, networkMap[key], nodeKey);
		}
	});
	nodes[nodeKey] = {
		id: nodeKey,
		_d: nodeValue,
		pid: prevNodeId,
		cids: cids,
		_w:cids.length
	};
	if (!cids.length) {
		ends.push(nodeKey);
	}
}
loopNode(handledNodes,startEl, startNode, null);



$(ends).each(function(index, item){
	var n = handledNodes[item];
	n._deep = 0;
	handledNodes[item] = n;
	loadDeep(n);
});


function loadDeep(n) {
	if (n.pid) {
		var p = handledNodes[n.pid];
		if (!p._deep || p._deep < n._deep + 1) {
			p._deep = n._deep + 1;
		}
		handledNodes[n.pid] = p;
		loadDeep(p);
	}
}

function sortNum(arrs) {
	$.each(arrs, function(key, values) {
		values.cids.sort(function(id1, id2){
			var ret =  arrs[id2]._deep - arrs[id1]._deep ;
			return ret;
		});
	});
}

sortNum(handledNodes);






// 110V母线
var first = data["BaseVoltage_110kV"];
createLineEl(layerSnap, {
	id : first.UUID
}, {
	x: currentSnapX,
	y: currentSnapY,
	x2: currentSnapX * 6,
	y2: currentSnapY,
	scale: 1
});

createTextEl(layerSnap, {
	id : first.name,
	title : first.name
}, {
	x: currentSnapX * 4.5,
	y: currentSnapY - 24,
	scale: 1,
	rotate: 0,
	txt: 'bkkV110',
	size:28
});

// 变电站
var second = data["Substation_14000131934513"];
second.__fromNode = false;
second.__forward = 1;
var prevSnap = {
	currentX: grid * 3,
	currentY: currentSnapY,
	x:0,
	y: grid,
	__forward: 1
};
prevSnap = createIcon(layerSnap, second, prevSnap);



var a = 0;
function createPoint(lay, y, nodeKey, x, parentPosition) {
	var n = handledNodes[nodeKey];
	var _node = nodes[n.id];
	n.type = nodeKey.indexOf("M") >=0 ? 'EnergyConsumer' : 'LoadBreakSwitch';
	if (n.type == 'LoadBreakSwitch' && _node.end) {
		n.type="Substation";
	}
	var realX = x + a;
	if(n.type == 'EnergyConsumer') {
		
		
		//画元素
		if (n.cids && n.cids.length) {
			// 线路上端点
			createUseEl(lay, {
				id: n.id + "_point",
				type: 'NZQG'
			}, {
				x: (realX + 2) * grid,
				y: (y + 2) * grid,
				scale: 1,
				rotate: 0
			});
			// 左侧备注
			createUseEl(lay, n, {
				x: (realX + 2) * grid - grid / 2 - 10,
				y: (y + 2) * grid,
				scale: 1,
				rotate: 90
			});
			// 左侧备注 连接线
			createLineEl(lay,{
				id: n.id + "_line_point"
			}, {
				scale: 1,
				x: (realX + 2) * grid + grid/2,
				y: (y + 2) * grid + grid/2,
				x2: (realX + 2) * grid - 10 + 24,
				y2: (y + 2) * grid  + grid/2
			});
			//备注
			createTextEl(lay, {
				id: n.id + "_txt",
				title : _node.SN
			}, {
				x: (realX + 2.5) * grid - 15,
				y: (y + 2.5) * grid + grid/2 + 5,
				scale: 1,
				rotate: 0
			});
		} else {
			createUseEl(lay, n, {
				x: (realX + 2) * grid,
				y: (y + 2) * grid,
				scale: 1,
				rotate: 0
			});
			//备注
			createTextEl(lay, {
				id: n.id + "_txt",
				title : _node.SN
			}, {
				x: (realX + 2.5) * grid + 10,
				y: (y + 2.5) * grid + 10 + grid / 2,
				scale: 1,
				rotate: 0
			});
		}
	} else if (n.type == 'Substation') {
		//画元素
		createUseEl(lay, n, {
			x: (realX + 2) * grid * 2 + (grid / 2),
			y: (y + 2) * grid * 2 + (grid / 2),
			scale: 0.5,
			rotate: 0
		});
		//备注
		createTextEl(lay, {
			id: n.id + "_txt",
			title : _node.name
		}, {
			x: (realX + 2.5) * grid - 5,
			y: (y + 2.5) * grid + 20,
			scale: 1,
			rotate: 90,
			txt: 'bkkV110',
			anchor: "start"
		});
	} else {
		//画元素
		createUseEl(lay, n, {
			x: (realX + 2) * grid,
			y: (y + 2) * grid,
			scale: 1,
			rotate: 0
		});
		//备注
		/*createTextEl(lay, {
			id: n.id + "_txt",
			title : _node.name
		}, {
			x: (realX + 2.5) * grid - 15,
			y: (y + 2.5) * grid + 5,
			scale: 1,
			rotate: 0
		});*/
	}
	
	// 画线
	var pos = {
		scale: 1,
		x: (parentPosition[1] + 2.5) * grid ,
		y: (parentPosition[0] + 2.5) * grid,
		x2: (realX + 2.5) * grid,
		y2: (y + 2.5) * grid
	};
	
	if (pos.x != pos.x2 && pos.y != pos.y2) {
		createLineEl(lay,{
			id: n.id + "_line_1"
		}, {
			scale: pos.scale,
			x: pos.x ,
			y: pos.y,
			x2: pos.x2,
			y2: pos.y
		});
		createLineEl(lay,{
			id: n.id + "_line_2"
		}, {
			scale: pos.scale,
			x: pos.x2 ,
			y: pos.y,
			x2: pos.x2,
			y2: pos.y2
		});
	} else {
		createLineEl(lay,{
			id: n.id + "_line"
		}, pos);
	}
	if (n.type == 'LoadBreakSwitch' && n.cids.length == 1 ) {
		var nextNode = handledNodes[n.cids[0]];
		var _next = nodes[nextNode.id];
		var type = nextNode.id.indexOf("M") >=0 ? 'EnergyConsumer' : 'LoadBreakSwitch';
		if (type == 'LoadBreakSwitch' && _next.end) {
			type ="Substation";
		}
		if (type == 'LoadBreakSwitch') {
			n = nextNode;
		}
	}
	$.each(n.cids, function(index, value) {
		createPoint(lay, y + 1, value, x + index, [y, realX]);
	});
	if (n.cids.length) {
		a += n.cids.length - 1;
	}
}

$.each(handledNodes[startEl].cids, function(index, value) {
	a += index;
	createPoint(layerSnap, 1, value, index + 1, [0, 1]);
});











/*
function handleNode(layer, node, prevNodeId, prev) {
	var currentNode = networkMap[node.UUID];
	
	node.cls = node.id.indexOf("M") >=0 ? 'NZQG' : 'LoadBreakSwitch';
	node.name = node.id.indexOf("M") >=0 ? node.SN : node.name;
	var prevSnap = createIcon(layer, node, prev, node.id.indexOf("M") < 0);
	
	var i = 1;
	$.each(currentNode, function(key, value) {
		if (key != prevNodeId) {
				var node1 = nodes[key];
				node1.id = key;
				node1.__forward = i;
				handleNode(layer, node1, node.id, prevSnap);
				i++;
		}
	});
}
*/

// 详细图
var svg = d3.select("body").append("svg");
svg.attr("width", 10000)
   .attr("height", 10000)
   .attr("xmlns", "http://www.w3.org/2000/svg")
   .attr("xmlns:xlink", "http://www.w3.org/1999/xlink")
   .attr("xmlns:cge", "http://iec.ch/TC57/2005/SVG-schema#");
var layer = svg.append("g").attr("id","Substation_Layer");

var grid = 64;
var currentX = grid * 1;
var currentY = grid * 1;

// 110V母线
var first = data["BaseVoltage_110kV"];
createLineEl(layer, {
	id : first.UUID
}, {
	x: currentX,
	y: currentY,
	x2: currentX * 6,
	y2: currentY,
	scale: 1
});

createTextEl(layer, {
	id : first.name,
	title : first.name
}, {
	x: currentX * 4.5,
	y: currentY - 24,
	scale: 1,
	rotate: 0,
	txt: 'bkkV110',
	size:28
});

// 变电站
var second = data["Substation_14000131934513"];
second.__fromNode = false;
second.__forward = 1;
var prev = {
	currentX: grid * 3,
	currentY: currentY,
	x:0,
	y: grid,
	__forward: 1
};
prev = createIcon(layer, second, prev);

// 断路器
var third = data["Breaker_14000191594737"];
third.__fromNode = false;
third.__forward = 1;
prev = createIcon(layer, third, prev);

// 第一个端点
var firstTerminal = null;
$.each(data, function(key, item){
	if (item.cls != 'BaseVoltage') {
		if (item._ConductingEquipment && item._ConductingEquipment.includes(third.UUID)) {
			firstTerminal = item;
			firstTerminal.__fromNode = false;
			firstTerminal.__forward = 1;
		}
	}
});

// 循环其他端点
drawTerminal(layer, firstTerminal, prev);


function getNodesByConnectivityNode(cNode) {
	var matcheds = [];
	$.each(data, function(key, item){
		if (item.cls != 'BaseVoltage') {
			if (item._ConnectivityNode && item._ConnectivityNode.includes(cNode)) {
				matcheds.push(item);
			}
		}
	});
	return matcheds;
}

function getNodesByConductingEquipment(cNode) {
	var matcheds = [];
	$.each(data, function(key, item){
		if (item.cls != 'BaseVoltage') {
			if (item._ConductingEquipment && item._ConductingEquipment.includes(cNode)) {
				matcheds.push(item);
			}
		}
	});
	return matcheds;
}


function drawTerminal(layer, terminal, previous, hideName) {
	if (terminal.__fromNode) {
	} else {
		// 画 节点 和 连接线
		var prev = previous;
		if (!terminal.__skip) {
			prev = createIcon(layer, terminal, previous, hideName);
		}
		
		if (terminal._ConnectivityNode && terminal._ConnectivityNode.length > 0) {
			var nodes = getNodesByConnectivityNode(terminal._ConnectivityNode[0]);
			if (nodes.length > 1) {
				var ii = 1;
				$(nodes).each(function(idx, node){
					if (node.UUID != terminal.UUID) {
						var nextT = node;
						if (nextT) {
							nextT.__fromNode = true;
							nextT.__forward = ii;
							ii++;
							if (nextT._ConductingEquipment && nextT._ConductingEquipment.length > 0) {
								var line = nextT._ConductingEquipment[0];
								var lineObj = data[line];
								if (lineObj.cls == 'ACLineSegment' || lineObj.cls ==  'Disconnector' || lineObj.cls ==  'LoadBreakSwitch') {
									var prev2 = prev;
									if (lineObj.cls ==  'Disconnector' || lineObj.cls ==  'LoadBreakSwitch') {
										lineObj.__fromNode = false;
										lineObj.__forward = nextT.__forward;
										prev2 = createIcon(layer, lineObj, prev);
									}
									var matcheds = getNodesByConductingEquipment(line);
									// 肯定只有一个
									if (matcheds.length > 1) {
										$(matcheds).each(function(idx, item){
											if (item.UUID != nextT.UUID) {
												item.__fromNode = false;
												item.__forward = lineObj.__forward ? 1 : nextT.__forward;
												item.__skip = lineObj.__forward ? true : false;
												drawTerminal(layer, item, prev2, true);
											}
										});
									} else if (lineObj.cls == 'ACLineSegment') {
										var item = lineObj;
										item.cls = 'NZQG';
										item.__fromNode = false;
										item.__forward = nextT.__forward;
										item.__skip = false;
										drawTerminal(layer, item, prev2, true);
									}
								} else {
									lineObj.__fromNode = false;
									lineObj.__forward = nextT.__forward;
									drawTerminal(layer, lineObj, prev);
								}
							}
						}
					}
				});
			}
		}
	}
}



function createIcon(layer, obj, prev, hideName ) {
	prev = prev || {
		currentX: 0,
		currentY:0,
		x: 0,
		y :0,
		__forward: 1
	};
	
	var cX = prev.currentX;
	var cY = prev.currentY;
	var __forward = prev.__forward;
	if (obj.__forward == 1) {
		if (prev.__forward == 1) {
			cY = cY + grid;
		} else if (prev.__forward == 2) {
			cX = cX + grid;
		}
	} else if (obj.__forward == 2) {
		if (prev.__forward == 2) {
			__forward = 1;
			cY = cY + grid;
		} else if (prev.__forward == 1) {
			__forward = 2;
			cX = cX + grid;
		}
	}
	
	var symbol = getSymbolByType(obj.cls);
	var name = obj.name || obj.mRID;
	
	createUseEl(layer, {
		id : obj.UUID,
		type: obj.cls
	}, {
		x: cX,
		y: cY,
		scale: 1,
		rotate: __forward == 1 ? symbol.r[0] : symbol.r[1]
	});
	if (!hideName) {
		var txtPostion = null;
		if (obj.cls == 'EnergyConsumer') {
			txtPostion = {
				x: __forward == 1 ? cX + grid/2 - 8 : cX + grid,
				y: __forward == 1 ? (cY  + grid ) : (cY  + grid / 2 + 4) ,
				scale: 1,
				rotate: __forward == 1 ? 90 : 0,
				txt: symbol.txt,
				size: symbol.size,
				anchor: 'start'
			};
		} else {
			txtPostion = {
				x: __forward == 1 ? cX : cX + grid / 2 - 9,
				y: __forward == 1 ? (cY  + grid / 2 + 9) : (cY  + prev.y - 10 ) ,
				scale: 1,
				rotate: __forward == 1 ? 0 : 90,
				txt: symbol.txt,
				size: symbol.size,
				anchor: null
			};
		}
		createTextEl(layer, {
			id : name,
			title : name
		}, txtPostion);
	}
	if (__forward == 1) {
		createLineEl(layer, {
			id : name + "_line"
		}, {
			x: cX + grid / 2,
			y: cY - prev.y,
			x2: cX + grid / 2,
			y2: cY + symbol.y,
			scale: 1
		});
	} else {
		createLineEl(layer, {
			id : name + "_line"
		}, {
			x: cX - prev.x,
			y: cY + grid / 2,
			x2: cX + symbol.x,
			y2: cY + grid / 2,
			scale: 1
		});
	}
	return {
		currentX: cX,
		currentY: cY,
		x: symbol.x,
		y: symbol.y,
		__forward: __forward
	};
}

function createTextEl(layer, data, position) {
	var g = layer.append("g").attr("id", data.id);
	var x = position.x;
	var y = position.y;
	var size = position.size || 14;
	var txtCls = position.txt || "fText";
	var anchor = position.anchor || "end";
	var txt = g.append('text').attr("text-anchor", anchor).attr("font-size", size).attr("stroke", "rgb(255,0,0)").attr("fill","rgb(255,0,0)").attr("x", x).attr("y", y).text(data.title).attr("class", txtCls).attr("transform","scale(" + position.scale + ") translate(0 0) rotate(" + position.rotate + " " + x + " " + y + ")");
}
function createUseEl(layer, data, position) {
	var g = layer.append("g").attr("id", data.id);
	var symbol = getSymbolByType(data.type)
	var x = position.x;
	var y = position.y;
	var transX = 0;
	var transY = 0;
	var rotate = position.rotate
	var rotateX = x + grid / 2;
	var rotateY = y + grid / 2;
	var useage = g.append('use').attr("width", grid).attr("height", grid).attr("transform","scale(" + position.scale + ") translate(" + transX + " " + transY + ") rotate(" + position.rotate + " " + rotateX + " " + rotateY + ")").attr("xlink:href", "#" + symbol.id ).attr("x", x).attr("y", y).attr("class", data.cls);
	if (lbss && data.type == 'Disconnector') {
	var connect = g.append('use').attr("width", grid).attr("height", grid).attr("transform","scale(" + position.scale + ") translate(" + transX + " " + transY + ") rotate(" + position.rotate + " " + rotateX + " " + rotateY + ")").attr("xlink:href", "#Disconnector_PD_刀闸@1").attr("x", x).attr("y", y).attr("class", "hide");
		lbss.push([useage, connect ]);
	}
}

function createLineEl(layer, data, position) {
	var g = layer.append("g").attr("id", data.id);
	var x = position.x * position.scale;
	var y = position.y * position.scale;
	var x2 = position.x2 * position.scale;
	var y2 = position.y2 * position.scale;
	var path = g.append('path').attr("stroke-width", 2).attr("stroke", "rgb(0,0,0)").attr("fill","none").attr("d", "M " + x + "," + y + " L " + x2 + "," + y2 + "");
	
	if (data.dash) {
		path.attr("stroke-dasharray", "3 3");
	}
}

function getSymbolByType(type) {
	var data = {
		id: "",
		x: "",
		y: ""
	};
	var id = "";
	switch(type) {
	case 'Substation':
		data = {
			id: "Substation_PD_变电站",
			x: 8,
			y: 12,
			txt: 'bkkV110',
			size:28,
			r: [0, 0]
		};
		break;
	case 'Breaker':
		data = {
			id: "Breaker_PD_变电站出线开关@1",
			x: 8,
			y: 8,
			r: [0, 90]
		};
		break;
	case 'Terminal':
		data = {
			id: "Pole_PD_直线砼杆0000",
			x: 32,
			y: 32,
			r: [0, 0]
		};
		break;
		
	case 'NZQG':
		data = {
			id: "Pole_PD_耐张砼杆",
			x: 26,
			y: 26,
			r: [0, 0]
		};
		break;
		
	case 'PowerTransformer':
		data = {
			id: "Transformer_PD_综合变压器",
			x: 12,
			y: 12,
			r: [0, 90]
		};
		break;
	case 'Disconnector':
		data = {
			id: "Disconnector_PD_刀闸@0",
			x: 26,
			y: 26,
			r: [0, 90]
		};
		break;
	case 'Connector':
		data = {
			id: "Disconnector_PD_刀闸@1",
			x: 26,
			y: 26,
			r: [0, 90]
		};
		break;
		
	case 'FHKG1':
		data = {
			id: "Breaker_PD_负荷开关@1",
			x: 26,
			y: 26,
			r: [0, 0]
		};
		break;
		
	case 'EnergyConsumer':
		data = {
			id: "EnergyConsumer_PD_单电源用户",
			x: 8,
			y: 8,
			r: [0, 90]
		};
		break;
	case 'LoadBreakSwitch':
		data = {
			id: "Breaker_PD_断路器@1",
			x: 22,
			y: 22,
			r: [0, 90]
		};
		break;
	case 'ZDT':
		data = {
			id: "Junction_PD_终端头",
			x: 26,
			y: 26,
			r: [0, 0]
		};
		break;
		
		
	default:
		break;
	}
	return data;
}



function closeLbs() {
	$(lbss).each(function(index, item){
		var disc = item[0];
		var connect = item[1];
		disc.attr("class", "hide");
		connect.attr("class", "");
	});
}


function openLbs() {
	$(lbss).each(function(index, item){
		var disc = item[0];
		var connect = item[1];
		connect.attr("class", "hide");
		disc.attr("class", "");
	});
}