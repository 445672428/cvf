/* {
	77: {
		252: {
			0: {
				'weight': 0,
				'key': 1,
				'type': 's'
			}
		},
		78: {
			0: {
				'weight': 0,
				'key': 21,
				'type': 's'
			}
		}
	},
	78: {
		77: {
			0: {
				'weight': 0,
				'key': 21,
				'type': 's'
			}
		},
		'M27': {
			0: {
				
			}
		}
	},
	144: {
		253: {
			0: {
				'weight': 0,
				'key': 3,
				'type': 's'
			}
		},
		'M100': {
			0: {
				
			}
		}
	},
	157: {
		243: {
			0: {
				'weight': 0,
				'key': 6,
				'type': 's'
			}
		},
		'M100': {
			0: {
				
			}
		}
	},
	180: {
		181: {
			0: {
				'weight': 0,
				'key': 27,
				'type': 's'
			}
		},
		'M0': {
			0: {
				
			}
		}
	},
	181: {
		180: {
			0: {
				'weight': 0,
				'key': 27,
				'type': 's'
			}
		},
		'M143': {
			0: {
				
			}
		}
	},
	213: {
		214: {
			0: {
				'weight': 0,
				'key': 13,
				'type': 's'
			}
		},
		'M0': {
			0: {
				
			}
		}
	},
	214: {
		213: {
			0: {
				'weight': 0,
				'key': 13,
				'type': 's'
			}
		},
		'M27': {
			0: {
				
			}
		}
	},
	243: {
		157: {
			0: {
				'weight': 0,
				'key': 6,
				'type': 's'
			}
		},
		'M143': {
			0: {
				
			}
		}
	},
	252: {
		77: {
			0: {
				'weight': 0,
				'key': 1,
				'type': 's'
			}
		}
	},
	253: {
		144: {
			0: {
				'weight': 0,
				'key': 3,
				'type': 's'
			}
		}
	},
	254: {
		'M0': {
			0: {
				
			}
		}
	},
	'M0': {
		254: {
			0: {
				
			}
		},
		213: {
			0: {
				
			}
		},
		180: {
			0: {
				
			}
		}
	},
	'M27': {
		214: {
			0: {
				
			}
		},
		78: {
			0: {
				
			}
		}
	},
	'M143': {
		243: {
			0: {
				
			}
		},
		181: {
			0: {
				
			}
		}
	},
	'M100': {
		144: {
			0: {
				
			}
		},
		157: {
			0: {
				
			}
		}
	}
}*/


var networkMap ={
	56: {
		58: {
			0: {
				'weight': 0,
				'key': 16,
				'type': 's'
			}
		},
		'M27': {
			0: {
				
			}
		}
	},
	58: {
		56: {
			0: {
				'weight': 0,
				'key': 16,
				'type': 's'
			}
		},
		'M58': {
			0: {
				
			}
		}
	},
	60: {
		211: {
			0: {
				'weight': 0,
				'key': 20,
				'type': 's'
			}
		},
		'M60': {
			0: {
				
			}
		}
	},
	62: {
		251: {
			0: {
				'weight': 0,
				'key': 24,
				'type': 's'
			}
		},
		'M62': {
			0: {
				
			}
		}
	},
	64: {
		81: {
			0: {
				'weight': 0,
				'key': 15,
				'type': 's'
			}
		},
		'M64': {
			0: {
				
			}
		}
	},
	73: {
		80: {
			0: {
				'weight': 0,
				'key': 2,
				'type': 's'
			}
		},
		'M73': {
			0: {
				
			}
		}
	},
	77: {
		254: {
			0: {
				'weight': 0,
				'key': 19,
				'type': 's'
			}
		},
		78: {
			0: {
				'weight': 0,
				'key': 23,
				'type': 's'
			}
		}
	},
	78: {
		77: {
			0: {
				'weight': 0,
				'key': 23,
				'type': 's'
			}
		},
		'M27': {
			0: {
				
			}
		}
	},
	80: {
		73: {
			0: {
				'weight': 0,
				'key': 2,
				'type': 's'
			}
		},
		'M27': {
			0: {
				
			}
		}
	},
	81: {
		64: {
			0: {
				'weight': 0,
				'key': 15,
				'type': 's'
			}
		},
		'M27': {
			0: {
				
			}
		}
	},
	144: {
		252: {
			0: {
				'weight': 0,
				'key': 11,
				'type': 's'
			}
		},
		'M132': {
			0: {
				
			}
		}
	},
	157: {
		243: {
			0: {
				'weight': 0,
				'key': 14,
				'type': 's'
			}
		},
		'M132': {
			0: {
				
			}
		}
	},
	180: {
		181: {
			0: {
				'weight': 0,
				'key': 17,
				'type': 's'
			}
		},
		'M0': {
			0: {
				
			}
		}
	},
	181: {
		180: {
			0: {
				'weight': 0,
				'key': 17,
				'type': 's'
			}
		},
		'M160': {
			0: {
				
			}
		}
	},
	207: {
		242: {
			0: {
				'weight': 0,
				'key': 1,
				'type': 's'
			}
		},
		'M151': {
			0: {
				
			}
		}
	},
	211: {
		60: {
			0: {
				'weight': 0,
				'key': 20,
				'type': 's'
			}
		},
		'M27': {
			0: {
				
			}
		}
	},
	213: {
		214: {
			0: {
				'weight': 0,
				'key': 8,
				'type': 's'
			}
		},
		'M0': {
			0: {
				
			}
		}
	},
	214: {
		213: {
			0: {
				'weight': 0,
				'key': 8,
				'type': 's'
			}
		},
		'M27': {
			0: {
				
			}
		}
	},
	242: {
		207: {
			0: {
				'weight': 0,
				'key': 1,
				'type': 's'
			}
		},
		'M132': {
			0: {
				
			}
		}
	},
	243: {
		157: {
			0: {
				'weight': 0,
				'key': 14,
				'type': 's'
			}
		},
		'M160': {
			0: {
				
			}
		}
	},
	246: {
		247: {
			0: {
				'weight': 0,
				'key': 6,
				'type': 's'
			}
		},
		'M0': {
			0: {
				
			}
		}
	},
	247: {
		246: {
			0: {
				'weight': 0,
				'key': 6,
				'type': 's'
			}
		},
		'M248': {
			0: {
				
			}
		}
	},
	251: {
		62: {
			0: {
				'weight': 0,
				'key': 24,
				'type': 's'
			}
		},
		'M27': {
			0: {
				
			}
		}
	},
	252: {
		144: {
			0: {
				'weight': 0,
				'key': 11,
				'type': 's'
			}
		}
	},
	253: {
		'M0': {
			0: {
				
			}
		}
	},
	254: {
		77: {
			0: {
				'weight': 0,
				'key': 19,
				'type': 's'
			}
		}
	},
	'M0': {
		253: {
			0: {
				
			}
		},
		246: {
			0: {
				
			}
		},
		213: {
			0: {
				
			}
		},
		180: {
			0: {
				
			}
		}
	},
	'M27': {
		80: {
			0: {
				
			}
		},
		214: {
			0: {
				
			}
		},
		81: {
			0: {
				
			}
		},
		56: {
			0: {
				
			}
		},
		211: {
			0: {
				
			}
		},
		78: {
			0: {
				
			}
		},
		251: {
			0: {
				
			}
		}
	},
	'M58': {
		58: {
			0: {
				
			}
		}
	},
	'M60': {
		60: {
			0: {
				
			}
		}
	},
	'M62': {
		62: {
			0: {
				
			}
		}
	},
	'M64': {
		64: {
			0: {
				
			}
		}
	},
	'M73': {
		73: {
			0: {
				
			}
		}
	},
	'M160': {
		243: {
			0: {
				
			}
		},
		181: {
			0: {
				
			}
		}
	},
	'M132': {
		242: {
			0: {
				
			}
		},
		144: {
			0: {
				
			}
		},
		157: {
			0: {
				
			}
		}
	},
	'M151': {
		207: {
			0: {
				
			}
		}
	},
	'M248': {
		247: {
			0: {
				
			}
		}
	}
}
;
/*{
	77: {
		'name': 'ConnectivityNode_刀闸12_line6$断路器9_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	78: {
		'name': 'ConnectivityNode_断路器9_line3$刀闸13_line5',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	144: {
		'name': 'ConnectivityNode_刀闸6_line5$断路器5_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	157: {
		'name': 'ConnectivityNode_line371_p1$line471_p0$断路器4_line3',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	180: {
		'name': 'ConnectivityNode_刀闸18_line5$断路器14_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	181: {
		'name': 'ConnectivityNode_断路器14_line3$刀闸19_line6',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	213: {
		'name': 'ConnectivityNode_line189_p1断路器2_line3',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	214: {
		'name': 'ConnectivityNode_断路器2_line4$刀闸3_line6',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	243: {
		'name': 'ConnectivityNode_断路器4_line4$刀闸5_line5',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	252: {
		'name': '桥南唐西0031刀闸外线',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	253: {
		'name': '野西唐东004开关（三遥）外线',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	254: {
		'name': '许庄变',
		'vn_kv': 110.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	'M0': {
		'SN': 2915.0,
		'P': 2915.0,
		'Q': 0.0,
		'name': 'ConnectivityNode_变电站出线开关1_line22$line3_p0',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	'M27': {
		'SN': 5865.0,
		'P': 5865.0,
		'Q': 0.0,
		'name': 'ConnectivityNode_line31_p0$刀闸3_line5$故障指示仪1_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	'M143': {
		'SN': 2400.0,
		'P': 2400.0,
		'Q': 0.0,
		'name': 'ConnectivityNode_综合变压器10_line3line229_p1',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	'M100': {
		'SN': 2000.0,
		'P': 2000.0,
		'Q': 0.0,
		'name': 'ConnectivityNode_meXbbX136_p0$meXbbX273_p0',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	}
};*/




var nodes={
	56: {
		'name': 'ConnectivityNode_刀闸1_line6$断路器1_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	58: {
		'name': 'ConnectivityNode_断路器1_line3$line85_p0',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	60: {
		'name': 'ConnectivityNode_meXbbX457_p0$断路器15_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	62: {
		'name': 'ConnectivityNode_meXbbX454_p0$断路器7_line3',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	64: {
		'name': 'ConnectivityNode_meXbbX426_p0$断路器13_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	73: {
		'name': 'ConnectivityNode_meXbbX442_p0$断路器12_line3',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	77: {
		'name': 'ConnectivityNode_刀闸12_line6$断路器9_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	78: {
		'name': 'ConnectivityNode_断路器9_line3$刀闸13_line5',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	80: {
		'name': 'ConnectivityNode_刀闸16_line6$断路器12_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	81: {
		'name': 'ConnectivityNode_刀闸17_line5$断路器13_line3',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	144: {
		'name': 'ConnectivityNode_刀闸6_line5$断路器5_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	157: {
		'name': 'ConnectivityNode_line371_p1$line471_p0$断路器4_line3',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	180: {
		'name': 'ConnectivityNode_刀闸18_line5$断路器14_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	181: {
		'name': 'ConnectivityNode_断路器14_line3$刀闸19_line6',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	207: {
		'name': 'ConnectivityNode_line315_p0$断路器3_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	211: {
		'name': 'ConnectivityNode_断路器15_line3$刀闸20_line5',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	213: {
		'name': 'ConnectivityNode_line189_p1断路器2_line3',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	214: {
		'name': 'ConnectivityNode_断路器2_line4$刀闸3_line6',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	242: {
		'name': 'ConnectivityNode_line238_p1断路器3_line3',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	243: {
		'name': 'ConnectivityNode_断路器4_line4$刀闸5_line5',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	246: {
		'name': 'ConnectivityNode_刀闸8_line6$断路器6_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	247: {
		'name': 'ConnectivityNode_断路器6_line3$line249_p0',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	251: {
		'name': 'ConnectivityNode_刀闸9_line6$断路器7_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	252: {
		'name': '野西唐东004开关（三遥）外线',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true,
		'end': true
	},
	253: {
		'name': '许庄变',
		'vn_kv': 110.0,
		'type': 'b',
		'zone': null,
		'in_service': true,
		'end': true
	},
	254: {
		'name': '桥南唐西0031刀闸外线',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true,
		'end': true
	},
	'M0': {
		'SN': 415.0,
		'P': 415.0,
		'Q': 0.0,
		
		'name': 'ConnectivityNode_变电站出线开关1_line22$line3_p0',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	'M27': {
		'SN': 1760.0,
		'P': 1760.0,
		'Q': 0.0,
		
		'name': 'ConnectivityNode_line31_p0$刀闸3_line5$故障指示仪1_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	'M58': {
		'SN': 500.0,
		'P': 500.0,
		'Q': 0.0,
		
		'name': 'ConnectivityNode_断路器1_line3$line85_p0',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	'M60': {
		'SN': 945.0,
		'P': 945.0,
		'Q': 0.0,
		
		'name': 'ConnectivityNode_meXbbX457_p0$断路器15_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	'M62': {
		'SN': 1030.0,
		'P': 1030.0,
		'Q': 0.0,
		
		'name': 'ConnectivityNode_meXbbX454_p0$断路器7_line3',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	'M64': {
		'SN': 1000.0,
		'P': 1000.0,
		'Q': 0.0,
		
		'name': 'ConnectivityNode_meXbbX426_p0$断路器13_line4',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	'M73': {
		'SN': 630.0,
		'P': 630.0,
		'Q': 0.0,
		
		'name': 'ConnectivityNode_meXbbX442_p0$断路器12_line3',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	'M160': {
		'SN': 2400.0,
		'P': 2400.0,
		'Q': 0.0,
		
		'name': 'ConnectivityNode_line420_p1$line421_p0$line227_p0',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	'M132': {
		'SN': 1600.0,
		'P': 1600.0,
		'Q': 0.0,
		
		'name': 'ConnectivityNode_meXbbX241_p1$line372_p0$line494_p0',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	'M151': {
		'SN': 400.0,
		'P': 400.0,
		'Q': 0.0,
		
		'name': 'ConnectivityNode_line333_p1$综合变压器3_line3',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	},
	'M248': {
		'SN': 2500.0,
		'P': 2500.0,
		'Q': 0.0,
		
		'name': 'ConnectivityNode_单电源用户4_line3$line249_p1',
		'vn_kv': 10.0,
		'type': 'b',
		'zone': null,
		'in_service': true
	}
};
 